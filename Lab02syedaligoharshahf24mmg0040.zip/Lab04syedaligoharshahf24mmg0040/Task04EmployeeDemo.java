class Employee {
    String name, address;
    int year_of_joining;

    Employee(String n, int y, String a) {
        name = n;
        year_of_joining = y;
        address = a;
    }

    void printInfo() {
        System.out.printf("%-10s %-15d %-15s\n", name, year_of_joining, address);
    }
}

public class Task04EmployeeDemo {
    public static void main(String[] args) {
        Employee e1 = new Employee("Robert", 1994, "WallsStreat");
        Employee e2 = new Employee("Sam", 2000, "WallsStreat");
        Employee e3 = new Employee("John", 1999, "WallsStreat");

        System.out.println("Name       Year_of_Joining   Address");
        e1.printInfo();
        e2.printInfo();
        e3.printInfo();
    }
}
