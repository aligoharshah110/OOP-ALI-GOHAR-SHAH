class Circle {
    double radius;
    String color;

    // Default constructor
    Circle() {}

    void calculateArea() {
        double area = Math.PI * radius * radius;
        System.out.println("Area: " + area);
    }
}

public class Task01CircleDemo {
    public static void main(String[] args) {
        Circle red_circle = new Circle();
        Circle green_circle = new Circle();

        red_circle.radius = 5;
        red_circle.color = "Red";

        green_circle.radius = 7;
        green_circle.color = "Green";

        System.out.println("Red Circle Radius: " + red_circle.radius);
        System.out.println("Green Circle Radius: " + green_circle.radius);

        red_circle.calculateArea();
        green_circle.calculateArea();
    }
}
