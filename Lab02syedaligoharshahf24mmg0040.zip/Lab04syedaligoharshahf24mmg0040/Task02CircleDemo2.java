class Circle {
    double radius;
    String color;

    Circle(double r, String c) {
        radius = r;
        color = c;
    }

    double calculateArea() {
        return Math.PI * radius * radius;
    }
}

public class Task02CircleDemo2 {
    public static void main(String[] args) {
        Circle red_circle = new Circle(5, "Red");
        Circle green_circle = new Circle(7, "Green");

        System.out.println("Red Circle Area: " + red_circle.calculateArea());
        System.out.println("Green Circle Area: " + green_circle.calculateArea());
    }
}
