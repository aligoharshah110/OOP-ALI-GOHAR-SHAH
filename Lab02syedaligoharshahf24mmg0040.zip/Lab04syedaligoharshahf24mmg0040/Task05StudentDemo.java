class Student {
    int id;
    String name;
    double[] grades = new double[5];

    Student(int i, String n, double[] g) {
        id = i;
        name = n;
        for (int j = 0; j < 5; j++) {
            grades[j] = g[j];
        }
    }

    void display_average_grade() {
        double sum = 0;
        for (double grade : grades) {
            sum += grade;
        }
        System.out.println("Average grade: " + (sum / grades.length));
    }

    double[] calc_percentage() {
        double[] percentages = new double[5];
        for (int i = 0; i < 5; i++) {
            percentages[i] = (grades[i] / 200.0) * 100;
        }
        return percentages;
    }

    String concat_id_name() {
        return id + "_" + name;
    }
}

public class Task05StudentDemo {
    public static void main(String[] args) {
        double[] grades1 = {150, 160, 170, 180, 190};
        double[] grades2 = {100, 110, 120, 130, 140};

        Student s1 = new Student(1, "Ali", grades1);
        Student s2 = new Student(2, "Sara", grades2);

        s1.display_average_grade();
        double[] percents1 = s1.calc_percentage();
        System.out.println("Percentages of s1:");
        for (double p : percents1) System.out.print(p + "% ");
        System.out.println("\nID and Name: " + s1.concat_id_name());

        s2.display_average_grade();
        double[] percents2 = s2.calc_percentage();
        System.out.println("Percentages of s2:");
        for (double p : percents2) System.out.print(p + "% ");
        System.out.println("\nID and Name: " + s2.concat_id_name());
    }
}
