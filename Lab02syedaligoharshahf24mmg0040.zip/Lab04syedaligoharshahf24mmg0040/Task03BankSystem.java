class BankAccount {
    double balance;
    String accountNumber;

    BankAccount(String accNo, double initialBalance) {
        accountNumber = accNo;
        balance = initialBalance;
    }

    void deposit(double amount) {
        balance += amount;
    }

    void withdraw(double amount) {
        if (balance >= amount) {
            balance -= amount;
        } else {
            System.out.println("Insufficient balance for account " + accountNumber);
        }
    }

    void checkBalance() {
        System.out.println("Balance for " + accountNumber + ": " + balance);
    }
}

public class Task03BankSystem {
    public static void main(String[] args) {
        BankAccount acc1 = new BankAccount("A001", 1000);
        BankAccount acc2 = new BankAccount("A002", 500);

        acc1.deposit(500);
        acc2.deposit(1500);

        acc1.checkBalance();
        acc2.checkBalance();

        acc1.withdraw(500);
        acc1.checkBalance();

        acc2.withdraw(3000); 
}
