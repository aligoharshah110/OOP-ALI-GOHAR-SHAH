class Matrix {
    int rows, cols;
    int[][] matx;

    Matrix(int r, int c) {
        rows = r;
        cols = c;
        matx = new int[rows][cols];
    }

    void set_element(int r, int c, int val) {
        if (r >= 0 && r < rows && c >= 0 && c < cols) {
            matx[r][c] = val;
        } else {
            System.out.println("Invalid index");
        }
    }

    void get_matrix() {
        for (int[] row : matx) {
            for (int val : row) {
                System.out.print(val + "\t");
            }
            System.out.println();
        }
    }
}

public class Task06MatrixDemo {
    public static void main(String[] args) {
        Matrix matrix1 = new Matrix(4, 3);
        Matrix matrix2 = new Matrix(3, 3);

       
        int val = 1;
        for (int i = 0; i < 4; i++) {
            for (int j = 0; j < 3; j++) {
                matrix1.set_element(i, j, val++);
            }
        }
   
        val = 10;
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                matrix2.set_element(i, j, val++);
            }
        }

        matrix1.set_element(1, 2, 3);

        System.out.println("Matrix 1:");
        matrix1.get_matrix();

        System.out.println("Matrix 2:");
        matrix2.get_matrix();
    }
}
