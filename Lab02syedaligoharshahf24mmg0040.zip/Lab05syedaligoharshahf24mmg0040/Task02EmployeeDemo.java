class Employee {
    String name;
    int empID;
    double salary;
    
    Employee(String name, int empID, double salary) {
        this.name = name;
        this.empID = empID;
        this.salary = salary;
    }

    void increaseSalary(double amount) {
        salary += amount;
    }

    double calculateAnnualSalary() {
        return salary * 12;
    }

    void displayDetails() {
        System.out.println("Name: " + name);
        System.out.println("Employee ID: " + empID);
        System.out.println("Monthly Salary: $" + salary);
    }
}

public class Task02EmployeeDemo {
    public static void main(String[] args) {
        Employee e1 = new Employee("Ayesha Khan", 101, 5000);

        e1.increaseSalary(2000);

      
        e1.displayDetails();

        double annual = e1.calculateAnnualSalary();
        System.out.println("Annual Salary: $" + annual);
    }
}
