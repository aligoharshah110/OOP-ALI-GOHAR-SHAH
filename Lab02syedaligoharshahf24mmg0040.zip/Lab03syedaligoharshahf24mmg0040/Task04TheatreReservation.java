import java.util.Scanner;

public class Task04TheatreReservation {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        final int rows = 3;
        final int cols = 4;
        boolean[][] seats = new boolean[rows][cols];

        int choice;
        do {
            System.out.println("\n1. Display available seats");
            System.out.println("2. Reserve a seat");
            System.out.println("3. Exit");
            System.out.print("Enter your choice: ");
            choice = sc.nextInt();

            switch (choice) {
                case 1:
                    System.out.println("Available seats (false = available, true = reserved):");
                    for (int i = 0; i < rows; i++) {
                        for (int j = 0; j < cols; j++) {
                            System.out.print(seats[i][j] + " ");
                        }
                        System.out.println();
                    }
                    break;

                case 2:
                    System.out.print("Enter row (0-" + (rows - 1) + "): ");
                    int row = sc.nextInt();
                    System.out.print("Enter column (0-" + (cols - 1) + "): ");
                    int col = sc.nextInt();

                    if (row >= 0 && row < rows && col >= 0 && col < cols) {
                        if (!seats[row][col]) {
                            seats[row][col] = true;
                            System.out.println("Seat reserved successfully.");
                        } else {
                            System.out.println("Seat already reserved.");
                        }
                    } else {
                        System.out.println("Invalid row or column range.");
                    }
                    break;

                case 3:
                    System.out.println("Exiting...");
                    break;

                default:
                    System.out.println("Invalid choice!");
            }
        } while (choice != 3);
    }
}
