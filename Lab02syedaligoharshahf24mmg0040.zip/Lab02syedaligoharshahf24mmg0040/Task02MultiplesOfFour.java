import java.util.Scanner;

public class Task02MultiplesOfFour {
    public static void main(String[] args) {
        int[] numbers = new int[10];
        Scanner sc = new Scanner(System.in);

        System.out.println("Enter 10 numbers:");
        for (int i = 0; i < 10; i++) {
            numbers[i] = sc.nextInt();
        }

        int sum = 0;
        for (int num : numbers) {
            if (num % 4 == 0) {
                sum += num;
            }
        }

        System.out.println("Sum of multiples of 4: " + sum);
    }
}
