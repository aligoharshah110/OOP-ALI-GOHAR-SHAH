public class Task05CheckNMatrix {
    public static void main(String[] args) {
        int[][] matrix = {
            {1, 1, 0, 0, 1},
            {1, 0, 1, 0, 1},
            {1, 0, 0, 1, 1},
            {1, 0, 0, 0, 1}
        };

        boolean isN = true;
        int n = matrix.length;

        for (int i = 0; i < n; i++) {
            boolean hasStart = matrix[i][0] == 1;
            boolean hasEnd = matrix[i][n - 1] == 1;
            boolean hasMiddle = matrix[i][i] == 1;

            if (!(hasStart && hasEnd && hasMiddle)) {
                isN = false;
                break;
            }
        }

        if (isN)
            System.out.println("The matrix contains letter 'N'.");
        else
            System.out.println("The matrix does not contain letter 'N'.");
    }
}
