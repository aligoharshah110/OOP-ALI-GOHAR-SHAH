import java.util.Scanner;

public class Task07MinMaxCheck {
    public static void main(String[] args) {
        int[] nums = new int[10];
        Scanner sc = new Scanner(System.in);

        System.out.println("Enter 10 numbers:");
        for (int i = 0; i < 10; i++) {
            nums[i] = sc.nextInt();
        }

        int min = nums[0];
        int max = nums[0];

        for (int num : nums) {
            if (num < min) min = num;
            if (num > max) max = num;
        }

        System.out.println("Smallest number: " + min);
        System.out.println("Largest number: " + max);
        System.out.println("Is largest number a multiple of 2? " + (max % 2 == 0));
    }
}
