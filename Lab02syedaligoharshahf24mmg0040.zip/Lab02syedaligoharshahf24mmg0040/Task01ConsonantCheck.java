import java.util.Scanner;

public class Task01ConsonantCheck {
    public static void main(String[] args) {
        char[] const_arr = {'b','c','d','f','g','h','j','k','l','m','n','p','q','r','s','t','v','w','x','y','z'};
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter a character: ");
        char user_inp = sc.next().toLowerCase().charAt(0);

        boolean found = false;
        for (char c : const_arr) {
            if (c == user_inp) {
                found = true;
                break;
            }
        }

        if (found)
            System.out.println("It is a consonant.");
        else
            System.out.println("It is not a consonant.");
    }
}
